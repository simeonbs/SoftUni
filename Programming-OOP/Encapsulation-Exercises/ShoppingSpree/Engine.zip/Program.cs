﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using _03.ShoppingSpree;

namespace ShoppingSpree
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
